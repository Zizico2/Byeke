package dataStructures;

/**
 * @author Bernardo Antonio Borda d'Agua - 53648
 * Commands - user input
 */
public class OrderedDoubleList<K, V> implements Dictionary<K, V> {

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public V find(K key) {
        return null;
    }

    @Override
    public V insert(K key, V value) {
        return null;
    }

    @Override
    public V remove(K key) {
        return null;
    }

    @Override
    public Iterator<Entry<K, V>> iterator() {
        return null;
    }
}
