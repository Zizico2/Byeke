package dataStructures;

public class FullStackException extends RuntimeException{
    static final long serialVersionUID = 0L;
}

